package com.howtoprogram.retrofit2;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;

import org.junit.Ignore;
import org.junit.Test;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;

public class Retrofit2Test {
	@Ignore
    @Test
    public void testPostObject() throws IOException {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://localhost:7777/things/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BookResourceRetrofit2 bookResource = retrofit.create(BookResourceRetrofit2.class);
        //Book book = new Book("Java How To Program", 123);
        Book book = new Book("1", "Java How To Program", 77);

        Call<Book> call = bookResource.addBook(book);
        Response<Book> response = call.execute();
        
        System.out.println(response.raw());
        System.out.println(response.message());
        //System.out.println("Name: " + response.body().getName() + " Age: " + response.body().getAge());
        System.out.println("ID: " + response.body().get_Id() + " Name: " + response.body().getName() + " Age: " + response.body().getAge());
        System.out.println(response.headers());
        
        assertTrue(response.isSuccessful());

    }
	@Ignore
    @Test
    public void testPostJson() throws IOException {

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://httpbin.org/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BookResourceRetrofit2 bookResource = retrofit.create(BookResourceRetrofit2.class);
        Book book = new Book("1", "Java How To Program", 111);

        Call<Book> call = bookResource.addBook(book);
        Response<Book> response = call.execute();

        assertTrue(response.isSuccessful());

    }
	@Ignore
    @Test
    public void testPostForm() throws IOException {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://localhost:7777/things/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BookResourceRetrofit2 service = retrofit.create(BookResourceRetrofit2.class);

        Call<Book> call = service.updateBook("1", "Tom1", 2222);

        Response<Book> response = call.execute();
        
        System.out.println(response.raw());
        System.out.println(response.message());
        System.out.println(response.body());
        //System.out.println("ID: " + response.body().get_Id() + " Name: " + response.body().getName() + " Age: " + response.body().getAge());
        System.out.println(response.headers());
        
        assertTrue(response.isSuccessful());


    }
	@Ignore
    @Test
    public void testPostFormWithFieldMap() throws IOException {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://localhost:7777/things/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BookResourceRetrofit2 service = retrofit.create(BookResourceRetrofit2.class);
        Map<String, String> fieldsMap = new HashMap<>();
        fieldsMap.put("name","Joshua Bloch");
        fieldsMap.put("age","55555");
        fieldsMap.put("_id","1");
        Call<Book> call = service.updateBook(fieldsMap);

        Response<Book> response = call.execute();
        
        System.out.println(response.raw());
        System.out.println(response.message());
        System.out.println(response.body());
        //System.out.println("ID: " + response.body().get_Id() + " Name: " + response.body().getName() + " Age: " + response.body().getAge());
        System.out.println(response.headers());
        
        assertTrue(response.isSuccessful());

    }

    @Test
    public void testPostMultipart() throws IOException {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://localhost:3000/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BookResourceRetrofit2 service = retrofit.create(BookResourceRetrofit2.class);

        // create RequestBody instance from file
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("RestImage.png").getFile());
        
        //fileType is "image/png" for RestImage.png  
        String fileType = Files.probeContentType(file.toPath());
        RequestBody reqFile = RequestBody.create(MediaType.parse(fileType), file);

        // MultipartBody.Part is used to send also the actual file name
        MultipartBody.Part body = MultipartBody.Part.createFormData("picture", file.getName(), reqFile);

        // add book id part within the multipart request
        //RequestBody id = RequestBody.create(MediaType.parse("text/plain"), "fix");
        String id = "Test";
        
        //Call<Book> call = service.addBookCover(id, body);
        //Call<Void> call = service.addBookCover(body);
        Call<Void> call = service.addBookCover(id, body);
        
        Response<Void> response = call.execute();

     /*   call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call,
                                   Response<ResponseBody> response) {
                //Log.v("Upload", "success");
            	
                System.out.println(response.raw());
                System.out.println(response.message());
                System.out.println(response.body());
                //System.out.println("ID: " + response.body().get_Id() + " Name: " + response.body().getName() + " Age: " + response.body().getAge());
                System.out.println(response.headers());
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                //Log.e("Upload error:", t.getMessage());
            	System.out.println("fail");
            }
        });
      */
      
        System.out.println(response.raw());
        System.out.println(response.message());
        System.out.println(response.body());
        //System.out.println("ID: " + response.body().get_Id() + " Name: " + response.body().getName() + " Age: " + response.body().getAge());
        System.out.println(response.headers());
        
        
        assertTrue(response.isSuccessful());

    }
	@Ignore
    @Test
    public void testPostMultipart2() throws IOException {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://httpbin.org/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        BookResourceRetrofit2 service = retrofit.create(BookResourceRetrofit2.class);

        // create RequestBody instance from file
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("RestImage.png").getFile());

        RequestBody reqFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);

        RequestBody id = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(1l));

        Call<Book> call = service.addBookCover2(id, reqFile);

        Response<Book> response = call.execute();
        assertTrue(response.isSuccessful());

    }

}
