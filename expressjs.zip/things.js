var express = require('express');
var router = express.Router();

var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/my_db');

var personSchema = mongoose.Schema({
   name: String,
   age: Number
});

var Person = mongoose.model("Person", personSchema);

router.get('/:name/:id', function(req, res){
   res.send('id: ' + req.params.id + ' and name: ' + req.params.name);
});

router.get('/:id([0-5]{2})', function(req, res){
   res.send('id: ' + req.params.id);
});

router.post('/receive', function(req, res){
   console.log(req.body);
   res.send("recieved your request!");
});

router.get('/image_template', function(req, res){
   res.render('image_view');
});

router.get('/form_template', function(req, res){
   res.render('form_view');
});

router.get('/person', function(req, res){
   res.render('person');
});

router.get('/getPeople', function(req, res){
	Person.find(
	   function(err, response){
		    if(err)
				res.render('show_message', {message: "Database error", type: "error"});
			else{
				res.json(response);
				console.log(response);
			}
	});
});

router.post('/addPerson', function(req, res){
   var personInfo = req.body; //Get the parsed information
   
   if(!personInfo.name || !personInfo.age){
      res.render('show_message', {
         message: "Sorry, you provided worng info", type: "error"});
   } else {
      var newPerson = new Person({
         name: personInfo.name,
         age: personInfo.age,
      });
		
      newPerson.save(function(err, response){
         if(err)
            res.render('show_message', {message: "Database error", type: "error"});
         else{
            res.render('show_message', {
               message: "New person added", type: "success", pppp: personInfo});
			   //message: "New person added", type: "success", pppp: newPerson});
		 }
      });
   }
});

router.put('/update/:id', function(req, res){
   Person.findByIdAndUpdate(req.params.id, req.body, function(err, response){
      if(err) 
		  res.json({message: "Error in updating person with id " + req.params.id});
      res.json(response);
   });
});

router.delete('/delete/:id', function(req, res){
   Person.findByIdAndRemove(req.params.id, function(err, response){
      if(err) 
		  res.json({message: "Error in deleting record id " + req.params.id});
      else 
		  res.json({message: "Person with id " + req.params.id + " removed."});
   });
});

router.get('*', function(req, res){
   res.send('Sorry, this is an invalid URL.');
});

//export this router to use in our index.js
module.exports = router;