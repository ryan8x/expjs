package com.howtoprogram.retrofit2;

import java.awt.image.BufferedImage;
import java.net.URL;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class ShowImage {

	public static void main(String[] args) {
		/*
		  JFrame frame = new JFrame();
		  ImageIcon icon = new ImageIcon("RestImage.png");
		  JLabel label = new JLabel(icon);
		  frame.add(label);
		  frame.setDefaultCloseOperation
		         (JFrame.EXIT_ON_CLOSE);
		  frame.pack();
		  frame.setVisible(true);
		*/

        try {
            String path = "http://localhost:3000/picture/5a3af1c01fe1bd897ccd9022";

            URL url = new URL(path);
            BufferedImage image = ImageIO.read(url);

            JLabel label = new JLabel(new ImageIcon(image));
            //JLabel label = new JLabel(new ImageIcon(url))
            
            JFrame f = new JFrame();
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.getContentPane().add(label);
            f.pack();
            f.setLocation(200, 200);
            f.setVisible(true);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
	}

}
