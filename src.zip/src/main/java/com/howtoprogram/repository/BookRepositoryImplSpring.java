package com.howtoprogram.repository;

import java.util.Arrays;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.howtoprogram.domain.Book;
import com.howtoprogram.domain.Person;

public class BookRepositoryImplSpring {

  private static final String URI_BOOK = "http://localhost:7777/things/getPeople";
  private static final String URI_BOOK_POST = "http://localhost:7777/things/addPerson";

  private RestTemplate restTemplate = new RestTemplate();

  public void deleteBook(Long id) {
    restTemplate.delete(URI_BOOK + "/{id}", id);
  }

  public void updateBook(Book book) {
    restTemplate.put(URI_BOOK + "/{id}", book, book.getId());
  }


  public static void main(String[] args) {
	  
	/*    Person person = new Person("Effective Java", 5555);
	    BookRepositoryImplSpring bookRepository = new BookRepositoryImplSpring();
	    bookRepository.createPerson(person);
	    //Person createdPerson = bookRepository.createPerson(person);
	    //System.out.println(createdPerson);
	 */
	  
    BookRepositoryImplSpring repository = new BookRepositoryImplSpring();
    // Getting the first book from the RESTful service
    //Person person = repository.getAllPersons()[0];
    Person[] persons = repository.getAllPersons();
    
    for (Person p:persons) {
    	System.out.println("Name: " + p.getName() + "  Age: " + p.getAge());
    }
    
   //System.out.println(Arrays.asList(persons));
    
    // Try to delete the book
    //repository.deleteBook(book.getId());
  }

  public Person createPerson(Person person) {
    // Book createdBook = restTemplate.postForObject(URI_BOOK, book, Book.class);
    Person newPerson = restTemplate.postForObject(URI_BOOK_POST, person, Person.class);
    	return newPerson;
    	
  /*    ResponseEntity<Person> responseEntity = restTemplate.postForEntity(URI_BOOK_POST, person, Person.class);	
    Person createdBook = null;
    if (responseEntity.getStatusCode() == HttpStatus.CREATED) {
      createdBook = responseEntity.getBody();
    }
   return createdBook;
   */
  }



  public Person[] getAllPersons() {
	  Person[] persons = restTemplate.getForObject(URI_BOOK, Person[].class);
    return persons;
  }

  public Book findBookById(Long id) {
    return null;
  }



}
