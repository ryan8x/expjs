var express = require('express');
var app = express();
var fs = require("fs");

//app.use(express.static('public'));
app.get('/index.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "index.htm" );
})

app.get('/process_get', function (req, res) {
   // Prepare output in JSON format
   response = {
      first_name:req.query.first_name,
      last_name:req.query.last_name
   };
   console.log(response);
   res.end(JSON.stringify(response));
})


app.get('/listUsers', function (req, res) {
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       console.log( data );
       res.end( data );
   });
})

var user = {
   "user4" : {
      "name" : "ddd",
      "password" : "password4",
      "profession" : "teacher",
      "id": 4
   }
}

app.get('/post.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "post.htm" );
})

app.get('/delete.htm', function (req, res) {
   res.sendFile( __dirname + "/" + "delete.htm" );
})

app.post('/addUser', function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
	  if (err) {
		return console.error(err);
	  }
       users = JSON.parse( data );
       users["user4"] = user["user4"];
       console.log( users );
       res.end( JSON.stringify(users));
   });
})

app.get('/:id', function (req, res) {
   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
      var users = JSON.parse( data );
      var user = users["user" + req.params.id] 
      console.log( user );
      res.end( JSON.stringify(user));
   });
})

app.delete('/deleteUser', function (req, res) {

   // First read existing users.
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       users = JSON.parse( data );
       delete users["user" + 2];  //not working
       
       console.log( users );
       res.end( JSON.stringify(users));
   });
})


app.listen(7777);