package com.howtoprogram.domain;

public class Book {
	private String _id;
	private String name;
	private long age;
	
	public Book() {
		super();
	}
/*	
	public Book(String name, long age) {
		this("1", name, age);
		this.name = name;
		this.age = age;
	}
*/	
	public Book(String _id, String name, long age) {
		super();
		this._id = _id;
		this.name = name;
		this.age = age;
	}

	public String getId() {
		return _id;
	}

	public void setId(String _id) {
		this._id = _id;
	}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAge() {
		return age;
	}
	public void setAge(long age) {
		this.age = age;
	}
}