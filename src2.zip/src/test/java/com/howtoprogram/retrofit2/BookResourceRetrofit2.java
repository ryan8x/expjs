package com.howtoprogram.retrofit2;


import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.http.*;

import java.util.Map;

public interface BookResourceRetrofit2 {

    @FormUrlEncoded
    @POST("post")
    Call<Book> updateBook(@FieldMap Map<String, String> fieldsMap);
/*
    @Multipart
    @POST("uploadpicture")
    //Call<ResponseBody> addBookCover(@Part MultipartBody.Part photo);
    Call<ResponseBody> addBookCover(@Part("id") RequestBody id, @Part MultipartBody.Part photo);
*/

    @Multipart
    @POST("uploadpicture")
    //Call<Void> addBookCover(@Part MultipartBody.Part photo);
    Call<Void> addBookCover(@Part("description") String desc, @Part MultipartBody.Part photo);
    
    @POST("addPerson")
    Call<Book> addBook(@Body Book book);


    @FormUrlEncoded
    @POST("post")
    Call<Book> updateBook(@Field("_id") String _id, @Field("name") String name,
                          @Field("age") long age);


    @Multipart
    @POST("post")
    Call<Book> addBookCover2(@Part("id") RequestBody id, @Part("photo") RequestBody photo);
}
