package com.howtoprogram.domain;

public class Person {
	private Long id;
	private String name;
	private long age;
	
	public Person() {
		super();
	}
	
	public Person(String name, long age) {
		this(1L, name, age);
	}
	
	public Person(Long id, String name, long age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getAge() {
		return age;
	}
	public void setAge(long age) {
		this.age = age;
	}
}
