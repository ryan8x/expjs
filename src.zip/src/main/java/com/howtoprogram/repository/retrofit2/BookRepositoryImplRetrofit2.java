package com.howtoprogram.repository.retrofit2;

import java.util.List;

import com.howtoprogram.domain.Book;
//import com.howtoprogram.springwebclient.Person;
import com.howtoprogram.repository.cxf.BookResource;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class BookRepositoryImplRetrofit2 {
	private static final String URI_BOOK = "http://localhost:7777/things/";

	public Book updateBook(Book book) throws Exception {
		Retrofit retrofit = new Retrofit.Builder().baseUrl(URI_BOOK).addConverterFactory(GsonConverterFactory.create())
				.build();
		BookResourceRetrofit2 service = retrofit.create(BookResourceRetrofit2.class);

		return service.updateBook(book.getId(), book).execute().body();
	}

	public Book createBook(Book book) throws Exception {
		Retrofit retrofit = new Retrofit.Builder().baseUrl(URI_BOOK).addConverterFactory(GsonConverterFactory.create())
				.build();
		BookResourceRetrofit2 bookResource = retrofit.create(BookResourceRetrofit2.class);
		return bookResource.createBook(book).execute().body();

	}

	public List<Book> getAllBooks() throws Exception {
		Retrofit retrofit = new Retrofit.Builder().baseUrl(URI_BOOK).addConverterFactory(GsonConverterFactory.create())
				.build();
		BookResourceRetrofit2 bookResource = retrofit.create(BookResourceRetrofit2.class);
		Call<List<Book>> books = bookResource.getAllBooks();
		return books.execute().body();
	}

	public Call<Void> deleteBook(String id) {
		Retrofit retrofit = new Retrofit.Builder().baseUrl(URI_BOOK).addConverterFactory(GsonConverterFactory.create())
				.build();
		BookResourceRetrofit2 bookResource = retrofit.create(BookResourceRetrofit2.class);
		return bookResource.deleteBook(id);
	}

	public Book findBookById(Long id) {
		return null;
	}
	
	public static void main(String[] args) throws Exception {
		BookRepositoryImplRetrofit2 bookRepository = new BookRepositoryImplRetrofit2();
		List<Book> books = bookRepository.getAllBooks();
		//Book book = bookRepository.getAllBooks().get(0);
		//System.out.println("Name: " + book.getName() + "  Age: " + book.getAge());
	   /*
		for (Book b:books) {
	    	System.out.println("ID: " + b.get_Id() + " Name: " + b.getName() + "  Age: " + b.getAge());
	    }
		*/
		
		/*
		Book book = new Book("1", "hhh", 123);
		Book b1 = bookRepository.createBook(book);
		System.out.println("ID: " + b1.get_Id() + " Name: " + b1.getName() + " Age: " + b1.getAge());
	    */
		
		/*
		Book book = new Book("5a29d4f9321ab066fce536ac", "ccc", 555);
		Book b2 = bookRepository.updateBook(book);
		System.out.println("ID: " + b2.getId() + " Name: " + b2.getName() + " Age: " + b2.getAge());
		*/
		
		//bookRepository.deleteBook("5a2883cebe33da7904c73745");
		Call<Void> call = bookRepository.deleteBook("5a29d93f321ab066fce536ad");
		
		call.enqueue(new Callback<Void>() {
		    @Override
		    public void onResponse(Call<Void> call, Response<Void> response) {
		        System.out.println(response.code());
		        System.out.println(response.isSuccessful());
		        System.out.println(response.message());
		        System.out.println(response.body());
		        System.out.println(response.raw());
		        
		    }

		    @Override
		    public void onFailure(Call<Void> call, Throwable t) {
		        // handle failure
		    }
		});

	}
}
